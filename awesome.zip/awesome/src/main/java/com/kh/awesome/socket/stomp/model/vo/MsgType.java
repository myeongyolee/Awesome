package com.kh.awesome.socket.stomp.model.vo;

public enum MsgType {
	INIT, MESSAGE ,ALRAM
}
