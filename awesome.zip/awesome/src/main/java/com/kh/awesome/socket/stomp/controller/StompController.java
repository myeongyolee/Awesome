package com.kh.awesome.socket.stomp.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.kh.awesome.member.model.vo.Member;
import com.kh.awesome.socket.stomp.model.service.StompService;
import com.kh.awesome.socket.stomp.model.vo.ChatRoom;
import com.kh.awesome.socket.stomp.model.vo.Msg;

@Controller
public class StompController {
		
	Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	StompService stompService;
	
	//채팅방 가져오기
//	@GetMapping("/ws/stomp.do")
//	public void websocket(Model model,
//						  HttpSession session,
//						  @SessionAttribute(value="memberLoggedIn", required=false) Member memberLoggedIn){
//		logger.info("------------------ws stomp----------------------");
//		Optional<Integer> OpMemberCode = Optional.ofNullable(memberLoggedIn).map(Member::getMemberCode);
//		int memberCode = OpMemberCode.get();
//		String chatId = null;
//		
//		//chatId조회
//		//1.memberId로 등록한 chatroom존재여부 검사. 있는 경우 chatId 리턴.
//		Map<String, Integer> chatUser = new HashMap<>();
//		chatUser.put("memberCode", memberCode);
//		
//		chatId = stompService.findChatIdByMemberId(chatUser);
//		
//		//2.로그인을 하지 않았거나, 로그인을 해도 최초접속인 경우 chatId를 발급하고 db에 저장한다.
//		if(chatId == null){
//			chatId = getRandomChatId(15);//chat_randomToken -> jdbcType=char(20byte)
//			
//			List<ChatRoom> list = new ArrayList<>();
//			list.add(new ChatRoom(chatId,memberCode , "Y", null, null));
////			stompService.insertChatRoom(list);
//		}
//		//chatId가 존재하는 경우, 채팅내역 조회
//		else{
//			List<Msg> chatList = stompService.findChatListByChatId(chatId);
//			model.addAttribute("chatList", chatList);
//		}
//		
//		
//		
//		logger.info("memberId=[{}], chatId=[{}]",memberCode, chatId);
//		
//		
//		//비회원일 경우, httpSessionId값을 memberId로 사용한다. 
//		//클라이언트에서는 httpOnly-true로 설정된 cookie값은 document.cookie로 가져올 수 없다.
//		model.addAttribute("memberCode", memberCode);
//		model.addAttribute("chatId", chatId);
//	}
	@GetMapping("/ws/stomp.do")
	public ModelAndView websocket(Model model,
							ModelAndView mav,
						  HttpSession session,
						  @SessionAttribute(value="memberLoggedIn", required=false) Member memberLoggedIn){
		logger.info("------------------ws stomp----------------------");
		Optional<Integer> OpMemberCode = Optional.ofNullable(memberLoggedIn).map(Member::getMemberCode);
		int memberCode = OpMemberCode.get();
		
		//비회원일 경우, httpSessionId값을 memberId로 사용한다. 
		//클라이언트에서는 httpOnly-true로 설정된 cookie값은 document.cookie로 가져올 수 없다.
		model.addAttribute("memberCode", memberCode);
		
		mav.addObject("memberCode", memberCode);
		
		return mav;
	}
	
	/**
	 * 인자로 전달될 길이의 임의의 문자열을 생성하는 메소드
	 * 영대소문자/숫자의 혼합.
	 */
	private String getRandomChatId(int len){
		Random rnd = new Random();
		StringBuffer buf =new StringBuffer();
		buf.append("chat_");
		for(int i=0;i<len;i++){
			//임의의 참거짓에 따라 참=>영대소문자, 거짓=> 숫자
		    if(rnd.nextBoolean()){
		    	boolean isCap = rnd.nextBoolean();
		        buf.append((char)((int)(rnd.nextInt(26))+(isCap?65:97)));
		    }
		    else{
		        buf.append((rnd.nextInt(10))); 
		    }
		}
		return buf.toString();

	}
	
	/**
	 * - @MessageMapping 을 통해 메세지를 받고,
	 * - @SendTo 를 통해 메세지 전달. 작성된 주소를 구독하고 있는 client에게 메세지 전송
	 */
	@MessageMapping("/chat/{chatId}")
	@SendTo(value={"/chat/{chatId}"})
	public Msg sendEcho(Msg fromMessage, 
						@DestinationVariable String chatId){
		logger.info("fromMessage={}",fromMessage);
		logger.info("chatId={}",chatId);
		System.out.println("여기는 /chat"+fromMessage);
		
		stompService.insertChatLog(fromMessage);

		return fromMessage; 
	}
	
	public String codeToId(String memberCode) {
		return stompService.codeToId(memberCode);
	}
	
	
	@MessageMapping("/hello")
	@SendTo("/hello")
	public Msg stomp(Msg fromMessage,
					 @Header("simpSessionId") String sessionId,//WesocketSessionId값을 가져옴.
					 SimpMessageHeaderAccessor headerAccessor//HttpSessionHandshakeInterceptor빈을 통해 httpSession의 속성에 접근 가능함.
					 ){
		logger.info("fromMessage={}",fromMessage);
		logger.info("@Header sessionId={}",sessionId);
		
		//httpSession속성 가져오기
		String sessionIdFromHeaderAccessor = headerAccessor.getSessionId();//@Header sessionId와 동일
		Map<String,Object> httpSessionAttr = headerAccessor.getSessionAttributes();
		Member member = (Member)httpSessionAttr.get("memberLoggedIn");
		String httpSessionId = (String)httpSessionAttr.get("HTTP.SESSION.ID");//비회원인 경우 chatId로 사용함.
		logger.info("sessionIdFromHeaderAccessor={}",sessionIdFromHeaderAccessor);
		logger.info("httpSessionAttr={}",httpSessionAttr);
		logger.info("memberLoggedIn={}",member);
		
        return fromMessage; 
	}
}