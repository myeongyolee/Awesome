package com.kh.awesome.sms;

public class Test {

	public static void main(String[] args) {
		
		TempKey tk = new TempKey();
		System.out.println(tk.getKey(6));
		

	}

}
